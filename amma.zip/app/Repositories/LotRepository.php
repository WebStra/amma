<?php

namespace App\Repositories;

use App\Lot;
use App\Vendor;
use Carbon\Carbon;

class LotRepository extends Repository
{
    /**
     * @return Lot
     */
    public function getModel()
    {
        return new Lot();
    }

    /**
     * Create plain lot for attached items to him.
     *
     * @param Vendor $vendor
     * @return mixed
     */
    public function createDraft(Vendor $vendor)
    {
        return $this->getModel()
            ->create([
                'vendor_id' => $vendor->id
            ]);
    }

    public function find($slug)
    {
        if (is_numeric($slug))
            return $this->getModel()
                ->whereId((int) $slug)
                ->first();

        return $this->getModel()
            ->whereSlug($slug)
            ->first();
    }

    /**
     * Add empty lot or modify just existed (drafted)..
     *
     * @param $vendor
     * @return Lot|mixed
     */
    public function addLot($vendor)
    {
        if($lot = $this->getDraftedLot($vendor))
            return $lot;

        return $this->createDraft($vendor);
    }

    /**
     * Get drafted lot
     *
     * @param $vendor|null
     * @return Lot $Lot|null
     */
    public function getDraftedLot($vendor = null)
    {
        $query = $this->getModel();

        if($vendor)
            $query = $query->where('vendor_id', $vendor->id);

        $lot = $query->drafted()->first();

        return ($lot) ? $lot : null;
    }

    /**
     * Get user's lots.
     *
     * @param $user
     * @param $perPage
     * @return \Illuminate\Support\Collection|null
     */
    public function userLots($user, $perPage = 5)
    {
        $model = self::getModel();

        $vendors = [];

        $user->vendors()->active()->get()
            ->each(function($vendor) use (&$vendors){
                $vendors[] = $vendor->id;
            });

        $lots = $this->getModel()
            ->whereIn('vendor_id', $vendors)
            ->where('status', '!=', $model::STATUS_DELETED)
            ->paginate($perPage);

        return ($lots->count()) ? $lots : null;
    }

    /**
     * Delete lot.
     *
     * @param $lot
     */
    public function delete($lot)
    {
        $model = self::getModel();
        if($lot->status !== $model::STATUS_DELETED)
        {
            $lot->status = $model::STATUS_DELETED;

            $lot->save();
        }
    }

    /**
     * Convert string date to \Carbon/Carbon timestamp.
     *
     * @param $date
     * @return static
     */
    public function dateToTimestamp($date)
    {
        $dates = $this->reformatDateString($date);

        return Carbon::createFromDate($dates['y'], $dates['m'], $dates['d']);
    }

    /**
     * Reformat date.
     *
     * @param $date
     * @param string $delimiter
     * @return mixed
     */
    public function reformatDateString($date, $delimiter = '.')
    {
        $datas = explode($delimiter, $date);

        if(count($datas) == 3) {
            $new_date['d'] = $datas[0];
            $new_date['m'] = $datas[1];
            $new_date['y'] = $datas[2];
        } else {
            $now = Carbon::now();
            $new_date['d'] = $now->day;
            $new_date['m'] = $now->month;
            $new_date['y'] = $now->year;
        }

        return $new_date;
    }

    public function save($lot, array $data)
    {
        $lot->fill([
            'name'                      => isset($data['name']) ? $data['name'] : $lot->present()->renderDraftedName(),
            //            'category_id' => isset($data['category']) ? $data['category'] : null,
            'currency_id'               => isset($data['currency']) ? (int)$data['currency'] : null,
            'description'               => isset($data['description']) ? $data['description'] : null,
            'yield_amount'              => isset($data['yield_amount']) ? $data['yield_amount'] : null,
            'public_date'               => isset($data['public_date']) ? $this->dateToTimestamp($data['public_date']) : Carbon::now(),
            'expire_date'               => isset($data['expirate_date']) ? $this->dateToTimestamp($data['expirate_date']) : Carbon::now(),
            'comision'                  => isset($data['comision']) ? $data['comision'] : 0,
            'description_delivery'      => isset($data['description_delivery']) ? $data['description_delivery'] : null,
            'description_payment'       => isset($data['description_payment']) ? $data['description_payment'] : null,
        ])->save();
        return $lot;
    }


    /**
     * Change category.
     *
     * @param $lot
     * @param $category_id
     *
     * @return void
     */
    public function changeCategory($lot, $category_id)
    {
        $lot->fill([
            'category_id' => $category_id
        ])->save();
    }

    /**
     * Check if user can to change category.
     *
     * @param Lot $lot
     * @return bool
     */
    public function checkIfPossibleToChangeCategory(Lot $lot)
    {
        if(! count($lot->products))
            return true;

        return false;
    }

    public function getLatestLot($limit = 10)
    {
        return self::getModel()
            ->orderBy('id','DESC')
            ->active()
            ->limit($limit)
            ->get();
    }

    public function getExpireSoon($paginate = 10)
    {
        $query = $this->getModel()
            ->select('lots.*')
            ->where('lots.active', 1)
            ->where('lots.expire_date', '>', Carbon::now())
            ->orderBy('lots.expire_date', self::ASC);

        return $query->paginate($paginate);
    }

}