<?php

namespace App\Http\ViewComposers;

use App\Contracts\ViewComposerContract;

abstract class Composer implements ViewComposerContract
{
    
}