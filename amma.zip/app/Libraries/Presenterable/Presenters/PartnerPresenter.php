<?php

namespace App\Libraries\Presenterable\Presenters;

use App\Traits\HasImagesPresentable;

class PartnerPresenter extends Presenter
{
    use HasImagesPresentable;
}