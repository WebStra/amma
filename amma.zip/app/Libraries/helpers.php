<?php

//if (! function_exists('{`function_name`}')) {
//    /**
//     * Comment example
//     */
//    function `function_name`($args)
//    {
//        `func_body`
//    }
//}

//if (! function_exists('description')) {
//    /**
//     * Add description for field.
//     *
//     * @uses keyhunter/administrator package
//     *
//     * @param $desc string
//     * @return array
//     */
//    function description($desc)
//    {
//        return ['description' => $desc];
//    }
//}