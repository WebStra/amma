<?php

namespace App;

use Keyhunter\Administrator\Model\PageTranslation as MainPageTranslation;

class PageTranslation extends MainPageTranslation
{

}