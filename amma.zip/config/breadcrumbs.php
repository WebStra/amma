<?php

return [

	'view' => 'partials.breadcrumbs',

];
